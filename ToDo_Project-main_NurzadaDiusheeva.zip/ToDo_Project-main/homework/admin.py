from django.contrib import admin

from .models import ToDo, ToMeet, Habits



admin.site.register(ToDo)

admin.site.register(ToMeet)

admin.site.register(Habits)